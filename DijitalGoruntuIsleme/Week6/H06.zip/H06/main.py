import cv2
import numpy as np
import matplotlib.pyplot as plt

def binary_slicing(img, A, B, alt, ust):
    img_out = np.full_like(img, alt)
    aralik = np.logical_and(img>A, img<B)
    img_out[aralik] = ust
    return img_out

def linear_slicing(img,A, B, ust):
    img_out = img.copy()
    aralik = np.logical_and(img>A, img<B)
    img_out[aralik] = ust
    return img_out

def linear_slicing_reverse(img, A, B, ust):
    img_out = img.copy()

    # aralik1 = np.logical_and(img>=0, img<A)
    # aralik2 = np.logical_and(img>B, img<=255)
    # aralik = np.logical_or(aralik1,aralik2)
    aralik = np.logical_or(img<A, img>B)
    img_out[aralik] = ust
    return img_out



img_path = "./images/aortic_angiogram.tif"
img = cv2.imread(img_path, 0)

img_bs = binary_slicing(img,150,250,10,255)
img_ls = linear_slicing(img,150,250,255)
img_lsr = linear_slicing_reverse(img, 150,250, 0)

hstacked1 = np.hstack((img, img_bs))
hstacked2 = np.hstack((img_ls, img_lsr))

vstacked = np.vstack((hstacked1, hstacked2))

plt.imshow(vstacked, cmap="gray")
plt.show()


# a = np.array([1,2,3,4,5,6,7,8,9])
# b = np.full_like(a, 255)
# secilen = a>4
# c = a[secilen] 
# a[secilen] = 255
# print(a)

# secilen = np.logical_and(a>=4, a<=7)
# b= np.full_like(a, 0)
# b[secilen] = 255
# print(b)